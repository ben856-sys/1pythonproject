# Week 1: Personal Information Manager

My first complete Python program — stores and displays personal information
using variables, user input, and formatted string output.

## What it does

- Stores 4 pieces of static personal info (name, age, city, hobby)
- Asks the user for 2 more pieces of info (favorite food, favorite color)
- Validates that input isn't left empty
- Calculates age in months
- Displays everything in a clean, formatted layout

## How to run

```bash
python personal_info.py
```

You'll be prompted for your favorite food and favorite color; everything
else is filled in from the variables at the top of the script.

## Example

```
========================================
    PERSONAL INFORMATION MANAGER
========================================

Please tell me about yourself:
------------------------------
What's your favorite food? Pizza
What's your favorite color? Blue

========================================
        YOUR INFORMATION
========================================

Name:  Prajjwal
Age:   22 years (264 months old)
City:  Pune
Hobby: Coding

Favorite Food:  Pizza
Favorite Color: Blue

========================================
Thanks for using this program!
========================================
```

## Concepts practiced

- Variables and data types (`str`, `int`)
- `input()` and basic validation (empty-input loop)
- String methods (`.strip()`, `.title()`, `.capitalize()`)
- f-strings for formatted output
- Comments for code documentation

## Files

| File              | Purpose                                      |
|-------------------|-----------------------------------------------|
| `personal_info.py`| Main program                                  |
| `test_inputs.txt` | Sample inputs used to manually test the script|
| `.gitignore`      | Files/folders excluded from version control   |
