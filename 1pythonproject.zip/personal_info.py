# Personal Information Manager
# Author: Prajjwal
# Description: My first Python project - stores and displays personal info
#              using variables, user input, and formatted string output.

# ---------- Welcome message ----------
print("=" * 40)
print("    PERSONAL INFORMATION MANAGER")
print("=" * 40)
print()

# ---------- Step 2: Static information ----------
# Edit these with your actual details
name = "Prajjwal"          # string - your name
age = 22                   # integer - your age (edit to your real age)
city = "Pune"               # string - your city
hobby = "coding"            # string - your hobby

# ---------- Step 3: Get user input with validation ----------
print("Please tell me about yourself:")
print("-" * 30)

# .strip() removes accidental leading/trailing spaces before checking if empty
favorite_food = input("What's your favorite food? ").strip()
while favorite_food == "":
    print("Please enter a valid food!")
    favorite_food = input("What's your favorite food? ").strip()

favorite_color = input("What's your favorite color? ").strip()
while favorite_color == "":
    print("Please enter a valid color!")
    favorite_color = input("What's your favorite color? ").strip()

# .title() capitalizes each word nicely for display, regardless of how it was typed
favorite_food = favorite_food.title()
favorite_color = favorite_color.title()

# ---------- Step 6: Enhancement - age in months ----------
age_in_months = age * 12

# ---------- Step 4: Display formatted output ----------
print()
print("=" * 40)
print("        YOUR INFORMATION")
print("=" * 40)
print()

print(f"Name:  {name}")
print(f"Age:   {age} years ({age_in_months} months old)")
print(f"City:  {city}")
print(f"Hobby: {hobby.capitalize()}")
print()
print(f"Favorite Food:  {favorite_food}")
print(f"Favorite Color: {favorite_color}")
print()

# ---------- Goodbye message ----------
print("=" * 40)
print("Thanks for using this program!")
print("=" * 40)
